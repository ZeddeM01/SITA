package com.develovit.sita;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FormSidang extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form_pembimbing_ta);
    }
}